import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manualmovegroup',
  templateUrl: './manualmovegroup.component.html',
  styleUrls: ['./manualmovegroup.component.css']
})
export class ManualmovegroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

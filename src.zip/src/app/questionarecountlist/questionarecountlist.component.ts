import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-questionarecountlist',
  templateUrl: './questionarecountlist.component.html',
  styleUrls: ['./questionarecountlist.component.css']
})
export class QuestionarecountlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

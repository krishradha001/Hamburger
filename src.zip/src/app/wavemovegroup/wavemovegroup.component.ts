import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wavemovegroup',
  templateUrl: './wavemovegroup.component.html',
  styleUrls: ['./wavemovegroup.component.css']
})
export class WavemovegroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class questionare
{
    _id:number;
Department:string;
createdby:string;
 rolledoutdate:string;
questions: string;
            
}